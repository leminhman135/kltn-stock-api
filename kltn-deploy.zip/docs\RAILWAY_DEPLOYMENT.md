# 🚀 Railway Deployment Guide - KLTN Stock Prediction System

Complete step-by-step guide to deploy your KLTN project on Railway with PostgreSQL + n8n + FastAPI.

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Step 1: Create Railway Account](#step-1-create-railway-account)
4. [Step 2: Deploy PostgreSQL](#step-2-deploy-postgresql)
5. [Step 3: Initialize Database](#step-3-initialize-database)
6. [Step 4: Deploy FastAPI](#step-4-deploy-fastapi)
7. [Step 5: Deploy n8n](#step-5-deploy-n8n)
8. [Step 6: Configure Workflows](#step-6-configure-workflows)
9. [Step 7: Testing](#step-7-testing)
10. [Troubleshooting](#troubleshooting)
11. [Cost Estimation](#cost-estimation)

---

## Overview

### Architecture on Railway:

```
┌──────────────────────────────────────────────────┐
│             Railway Project: KLTN                │
│                                                  │
│  ┌────────────────┐  ┌────────────────┐        │
│  │   PostgreSQL   │  │   FastAPI      │        │
│  │   (Database)   │◄─┤   (Backend)    │        │
│  │   Port: 5432   │  │   Port: 8000   │        │
│  └────────────────┘  └────────────────┘        │
│         ▲                     ▲                  │
│         │                     │                  │
│         │         ┌───────────────┐             │
│         └─────────┤     n8n       │             │
│                   │  (Automation) │             │
│                   │   Port: 5678  │             │
│                   └───────────────┘             │
│                                                  │
│  All services have public URLs:                 │
│  • db: containers-us-west-xxx.railway.app:5432 │
│  • api: kltn-api.up.railway.app                │
│  • n8n: kltn-n8n.up.railway.app                │
└──────────────────────────────────────────────────┘
```

---

## Prerequisites

- ✅ GitHub account (để link với Railway)
- ✅ Code đã push lên GitHub repository
- ✅ Email để đăng ký Railway
- ✅ Credit card (optional, cho paid plan)

---

## Step 1: Create Railway Account

### 1.1 Sign Up

1. Truy cập: https://railway.app
2. Click **"Start a New Project"**
3. Đăng nhập bằng GitHub:
   - Click "Login with GitHub"
   - Authorize Railway app
4. Verify email

### 1.2 Free Tier Limits

Railway Free Tier (2024):
- ✅ $5 credit/month
- ✅ 500 hours runtime/month
- ✅ 1 GB RAM per service
- ✅ 1 GB disk
- ⚠️ Credit card required after trial

**Note**: $5/month đủ cho KLTN demo (3 services nhỏ).

---

## Step 2: Deploy PostgreSQL

### 2.1 Create Database

1. **New Project**:
   ```
   Railway Dashboard → New Project → "Deploy PostgreSQL"
   ```

2. **Wait for deployment** (~30 seconds)

3. **Get connection details**:
   ```
   PostgreSQL service → Connect → Copy variables:
   
   DATABASE_URL=postgresql://postgres:PASSWORD@containers-us-west-XXX.railway.app:5432/railway
   PGHOST=containers-us-west-XXX.railway.app
   PGPORT=5432
   PGUSER=postgres
   PGPASSWORD=XXX
   PGDATABASE=railway
   ```

### 2.2 Test Connection (Local)

```bash
# Install psql client
# Windows: Download from https://www.postgresql.org/download/windows/
# Mac: brew install postgresql
# Linux: sudo apt install postgresql-client

# Test connection
psql "postgresql://postgres:PASSWORD@containers-us-west-XXX.railway.app:5432/railway"

# If successful, you'll see:
railway=> \l  # List databases
railway=> \q  # Quit
```

---

## Step 3: Initialize Database

### 3.1 Update Local `.env`

Create `.env` file:
```bash
# Copy from Railway PostgreSQL service
DATABASE_URL=postgresql://postgres:PASSWORD@containers-us-west-XXX.railway.app:5432/railway
```

### 3.2 Run Migrations

```bash
# Install dependencies
pip install -r requirements.txt

# Run Alembic migrations
alembic upgrade head

# Output:
# INFO  [alembic.runtime.migration] Running upgrade  -> 001, Initial database schema
# ✅ Database tables created successfully!
```

### 3.3 Verify Tables

```bash
# Connect to Railway database
psql $DATABASE_URL

# Check tables
railway=> \dt

# Expected output:
          List of relations
 Schema |         Name          | Type  |  Owner  
--------+-----------------------+-------+---------
 public | stocks                | table | postgres
 public | stock_prices          | table | postgres
 public | technical_indicators  | table | postgres
 public | sentiment_analysis    | table | postgres
 public | model_metrics         | table | postgres
 public | predictions           | table | postgres
 public | news_articles         | table | postgres
 public | alembic_version       | table | postgres
```

### 3.4 Seed Initial Data (Optional)

```bash
# Create seed data
python -c "
from src.database.connection import SessionLocal
from src.database.models import Stock

db = SessionLocal()

stocks = [
    Stock(symbol='VNM', name='Vinamilk', exchange='HOSE', sector='Consumer', is_active=True),
    Stock(symbol='VIC', name='Vingroup', exchange='HOSE', sector='Real Estate', is_active=True),
    Stock(symbol='HPG', name='Hoa Phat Group', exchange='HOSE', sector='Materials', is_active=True),
    Stock(symbol='VCB', name='Vietcombank', exchange='HOSE', sector='Financials', is_active=True),
    Stock(symbol='FPT', name='FPT Corporation', exchange='HOSE', sector='Technology', is_active=True),
    Stock(symbol='VHM', name='Vinhomes', exchange='HOSE', sector='Real Estate', is_active=True),
    Stock(symbol='MSN', name='Masan Group', exchange='HOSE', sector='Consumer', is_active=True),
    Stock(symbol='CTG', name='VietinBank', exchange='HOSE', sector='Financials', is_active=True),
    Stock(symbol='TCB', name='Techcombank', exchange='HOSE', sector='Financials', is_active=True),
    Stock(symbol='BID', name='BIDV', exchange='HOSE', sector='Financials', is_active=True),
]

db.bulk_save_objects(stocks)
db.commit()
print('✅ 10 stocks seeded')
"
```

---

## Step 4: Deploy FastAPI

### 4.1 Prepare Repository

Tạo file `Procfile` trong root project:
```
web: uvicorn src.api_v2:app --host 0.0.0.0 --port $PORT
```

Tạo file `runtime.txt`:
```
python-3.11.6
```

Tạo file `.railwayignore`:
```
__pycache__/
*.pyc
.env
.git/
venv/
data/raw/
data/processed/
automation/logs/
*.log
```

### 4.2 Push to GitHub

```bash
git add .
git commit -m "Prepare for Railway deployment"
git push origin main
```

### 4.3 Deploy on Railway

1. **Add New Service**:
   ```
   Railway Dashboard → Your Project → "New" → "GitHub Repo"
   ```

2. **Select Repository**:
   - Choose your KLTN repository
   - Branch: `main`

3. **Configure Service**:
   ```
   Service name: kltn-api
   Start command: (auto-detected from Procfile)
   ```

4. **Add Environment Variables**:
   ```
   Settings → Variables → Add Reference:
   
   DATABASE_URL = ${{Postgres.DATABASE_URL}}
   PORT = 8000
   ENVIRONMENT = production
   ```

5. **Generate Domain**:
   ```
   Settings → Networking → Generate Domain
   
   ✅ Your API URL: https://kltn-api.up.railway.app
   ```

6. **Deploy**:
   - Railway tự động build & deploy
   - Xem logs: View Logs → Build logs → Deploy logs

### 4.4 Test API

```bash
# Health check
curl https://kltn-api.up.railway.app/api/health

# Expected:
{
  "status": "healthy",
  "timestamp": "2024-11-30T12:00:00",
  "database": "connected",
  "stocks_count": 10,
  "price_records": 0
}

# API docs
open https://kltn-api.up.railway.app/docs
```

---

## Step 5: Deploy n8n

### 5.1 Add n8n Service

1. **New Service → Docker Image**:
   ```
   Railway → New → "Deploy a Docker Image"
   
   Image: n8nio/n8n:latest
   Service name: kltn-n8n
   ```

2. **Configure Environment**:
   ```
   Settings → Variables:
   
   N8N_PORT = 5678
   N8N_PROTOCOL = https
   N8N_HOST = ${{RAILWAY_PUBLIC_DOMAIN}}
   WEBHOOK_URL = https://${{RAILWAY_PUBLIC_DOMAIN}}
   
   # Database (for n8n data)
   DB_TYPE = postgresdb
   DB_POSTGRESDB_HOST = ${{Postgres.PGHOST}}
   DB_POSTGRESDB_PORT = ${{Postgres.PGPORT}}
   DB_POSTGRESDB_DATABASE = ${{Postgres.PGDATABASE}}
   DB_POSTGRESDB_USER = ${{Postgres.PGUSER}}
   DB_POSTGRESDB_PASSWORD = ${{Postgres.PGPASSWORD}}
   
   # Security
   N8N_BASIC_AUTH_ACTIVE = true
   N8N_BASIC_AUTH_USER = admin
   N8N_BASIC_AUTH_PASSWORD = YourSecurePassword123
   ```

3. **Generate Domain**:
   ```
   Settings → Networking → Generate Domain
   
   ✅ n8n URL: https://kltn-n8n.up.railway.app
   ```

4. **Deploy** (~1 minute)

### 5.2 Access n8n

1. Open: https://kltn-n8n.up.railway.app
2. Login với credentials (admin / YourSecurePassword123)
3. Setup owner account (first time)

---

## Step 6: Configure Workflows

### 6.1 Add PostgreSQL Credential in n8n

1. **n8n → Credentials → New**
2. **Type**: Postgres
3. **Fill in details**:
   ```
   Name: Railway KLTN Database
   Host: containers-us-west-XXX.railway.app
   Database: railway
   User: postgres
   Password: [from Railway]
   Port: 5432
   SSL: Allow
   ```
4. **Test** → Save

### 6.2 Import Workflows

1. **Download workflows**:
   - See `automation/N8N_WORKFLOWS.md`
   - 7 workflow JSONs

2. **Import each workflow**:
   ```
   n8n → Workflows → Import from File
   
   ✅ 1. KLTN - Stock Data Collection
   ✅ 2. KLTN - Data Processing
   ✅ 3. KLTN - Technical Indicators
   ✅ 4. KLTN - Sentiment Analysis
   ✅ 5. KLTN - Model Training
   ✅ 6. KLTN - Data Backup
   ✅ 7. KLTN - Cleanup
   ```

3. **Update API URLs** in workflows:
   ```javascript
   // Replace in HTTP Request nodes:
   const API_URL = 'https://kltn-api.up.railway.app';
   ```

4. **Activate all workflows**

### 6.3 Test Workflows

1. **Manual test**:
   ```
   Workflow 1 (Data Collection) → Execute Workflow
   ```

2. **Check logs**:
   ```
   n8n → Executions → View details
   ```

3. **Verify database**:
   ```bash
   psql $DATABASE_URL -c "SELECT COUNT(*) FROM stock_prices;"
   ```

---

## Step 7: Testing

### 7.1 Test Complete Flow

```bash
# 1. Trigger data collection (manually in n8n)
# Workflow 1 → Execute

# 2. Check database
psql $DATABASE_URL -c "
SELECT 
  s.symbol, 
  COUNT(sp.id) as price_count,
  MAX(sp.date) as latest_date
FROM stocks s
LEFT JOIN stock_prices sp ON s.id = sp.stock_id
GROUP BY s.symbol;
"

# 3. Test API
curl https://kltn-api.up.railway.app/api/stocks
curl https://kltn-api.up.railway.app/api/prices/VNM?limit=10
curl https://kltn-api.up.railway.app/api/stats/overview

# 4. Check indicators
curl https://kltn-api.up.railway.app/api/indicators/VNM/latest
```

### 7.2 Monitor Resources

```
Railway Dashboard → Service → Metrics

CPU Usage: Should be < 50%
Memory: Should be < 512 MB
Network: Inbound/Outbound traffic
```

---

## Troubleshooting

### ❌ Database Connection Failed

**Error**: `FATAL: password authentication failed`

**Solution**:
```bash
# 1. Verify DATABASE_URL
echo $DATABASE_URL

# 2. Test connection
psql $DATABASE_URL

# 3. Check Railway variables
Railway → PostgreSQL → Variables → Copy again
```

### ❌ API 502 Bad Gateway

**Error**: `502 Bad Gateway`

**Solution**:
```bash
# 1. Check build logs
Railway → kltn-api → Deployments → View logs

# 2. Check if port is correct
# In Procfile:
web: uvicorn src.api_v2:app --host 0.0.0.0 --port $PORT

# 3. Restart service
Railway → kltn-api → Settings → Restart
```

### ❌ n8n Workflows Not Running

**Error**: Workflows not triggering

**Solution**:
```
# 1. Check execution history
n8n → Executions → Filter by "Error"

# 2. Verify PostgreSQL credential
n8n → Credentials → Test connection

# 3. Check webhook URL
n8n → Settings → Check WEBHOOK_URL variable
```

### ❌ Alembic Migration Failed

**Error**: `Target database is not up to date`

**Solution**:
```bash
# Check current version
alembic current

# Stamp to latest
alembic stamp head

# Or upgrade
alembic upgrade head
```

---

## Cost Estimation

### Free Tier ($5 credit/month)

**Breakdown:**
```
PostgreSQL: ~$0.50/month (minimal usage)
FastAPI:    ~$2.00/month (~300 hours)
n8n:        ~$2.00/month (~300 hours)
─────────────────────────────────────
Total:      ~$4.50/month ✅ Within free tier
```

**Usage tips to stay free:**
- Tắt services khi không demo
- Giới hạn executions/month
- Optimize queries
- Use caching

### Paid Plan ($5/month)

```
Hobby Plan: $5/month
- 500 hours → Unlimited hours
- 1 GB RAM → 8 GB RAM
- No credit card required → Billed monthly
- All services can run 24/7
```

**Recommendation**: Start free → Upgrade if needed cho KLTN báo cáo

---

## Production Checklist

Before going production:

- [ ] Enable SSL (Railway auto-provides)
- [ ] Setup custom domain (optional)
- [ ] Configure CORS properly
- [ ] Add API rate limiting
- [ ] Setup monitoring (Railway metrics)
- [ ] Enable database backups
- [ ] Add error notifications
- [ ] Document API endpoints
- [ ] Create user authentication
- [ ] Setup CI/CD (Railway auto-deploys on push)

---

## Next Steps

1. ✅ **Data Collection**: Workflows chạy tự động theo schedule
2. ✅ **API Development**: Thêm endpoints mới trong `src/api_v2.py`
3. ✅ **Frontend**: Deploy Streamlit app (`src/web_app.py`)
4. ✅ **Model Training**: Implement training logic
5. ✅ **Monitoring**: Setup alerts & dashboards

---

## Useful Commands

```bash
# View Railway logs
railway logs --service kltn-api

# Run migrations on Railway
railway run alembic upgrade head

# Connect to Railway database
railway connect Postgres

# Deploy from CLI
railway up

# Restart service
railway restart --service kltn-api
```

---

## Support Resources

- **Railway Docs**: https://docs.railway.app
- **Railway Discord**: https://discord.gg/railway
- **n8n Community**: https://community.n8n.io
- **PostgreSQL Docs**: https://www.postgresql.org/docs/

---

## 🎉 Congratulations!

Your KLTN Stock Prediction System is now running on:
- ✅ **Railway PostgreSQL** - Database
- ✅ **Railway FastAPI** - Backend API
- ✅ **Railway n8n** - Automation workflows

**Total setup time**: ~30 minutes

**Monthly cost**: $0-5 (free tier sufficient for KLTN)

---

**📚 See also:**
- `automation/N8N_WORKFLOWS.md` - Detailed workflow configurations
- `.env.example` - Environment variables template
- `src/database/models.py` - Database schema reference
