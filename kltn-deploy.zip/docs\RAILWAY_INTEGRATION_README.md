# Railway + PostgreSQL + n8n Integration for KLTN

## 🎯 Tổng Quan

Dự án đã được tích hợp **Railway + PostgreSQL + n8n** để thay thế CSV storage và Python scheduler.

### Architecture:

```
┌─────────────────────────────────────────────────────────┐
│                    KLTN System v2.0                     │
│                                                         │
│  ┌──────────────┐      ┌──────────────┐              │
│  │  PostgreSQL  │◄─────┤   FastAPI    │              │
│  │  (Railway)   │      │   Backend    │              │
│  └──────────────┘      └──────────────┘              │
│         ▲                      ▲                       │
│         │                      │                       │
│         │          ┌───────────────────┐              │
│         └──────────┤       n8n         │              │
│                    │   (Automation)    │              │
│                    └───────────────────┘              │
│                                                         │
│  Data Flow:                                            │
│  1. n8n triggers data collection (Daily 18:00)        │
│  2. VNDirect API → n8n → PostgreSQL                   │
│  3. n8n calculates indicators → PostgreSQL            │
│  4. FastAPI serves data from PostgreSQL               │
│  5. Streamlit displays via FastAPI endpoints          │
└─────────────────────────────────────────────────────────┘
```

---

## 📁 New Files Added

### Database Layer:
- ✅ `src/database/__init__.py` - Database module exports
- ✅ `src/database/connection.py` - SQLAlchemy engine & session
- ✅ `src/database/models.py` - 7 database models (Stock, StockPrice, TechnicalIndicator, etc.)
- ✅ `src/database/helpers.py` - Helper functions for CRUD operations

### Migrations:
- ✅ `alembic.ini` - Alembic configuration
- ✅ `alembic/env.py` - Migration environment
- ✅ `alembic/versions/001_initial_schema.py` - Initial database schema

### API:
- ✅ `src/api_v2.py` - Enhanced FastAPI with 20+ endpoints
  - `/api/stocks` - List all stocks
  - `/api/prices/{symbol}` - Historical prices
  - `/api/indicators/{symbol}` - Technical indicators
  - `/api/predictions/{symbol}` - Predictions
  - `/api/sentiment/{symbol}` - Sentiment analysis
  - `/api/models` - Model metrics
  - `/api/stats/overview` - System statistics

### Documentation:
- ✅ `docs/RAILWAY_DEPLOYMENT.md` - Complete Railway deployment guide
- ✅ `automation/N8N_WORKFLOWS.md` - 7 n8n workflow configurations

### Testing:
- ✅ `test_railway_setup.py` - Comprehensive setup validation script

### Configuration:
- ✅ `.env.example` - Updated with Railway/PostgreSQL variables
- ✅ `requirements.txt` - Added psycopg2-binary, SQLAlchemy, alembic

---

## 🚀 Quick Start

### 1. Local Development Setup:

```bash
# Install dependencies
pip install -r requirements.txt

# Setup local PostgreSQL (Docker)
docker run -d \
  --name kltn-postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=kltn_stocks \
  -p 5432:5432 \
  postgres:15

# Configure environment
cp .env.example .env
# Edit .env with local DATABASE_URL

# Run migrations
alembic upgrade head

# Test connection
python test_railway_setup.py

# Start API
uvicorn src.api_v2:app --reload

# Open docs
http://localhost:8000/docs
```

### 2. Railway Deployment:

See detailed guide: **[docs/RAILWAY_DEPLOYMENT.md](docs/RAILWAY_DEPLOYMENT.md)**

```bash
# Quick steps:
1. Create Railway account (GitHub login)
2. Deploy PostgreSQL (1 click)
3. Push code to GitHub
4. Deploy FastAPI from GitHub repo
5. Deploy n8n (Docker image: n8nio/n8n)
6. Import workflows from automation/N8N_WORKFLOWS.md
7. Activate all 7 workflows
```

**Total time**: ~30 minutes  
**Cost**: $0-5/month (free tier sufficient)

### 3. n8n Workflows Setup:

See: **[automation/N8N_WORKFLOWS.md](automation/N8N_WORKFLOWS.md)**

7 workflows to import:
1. ✅ Data Collection (Daily 18:00)
2. ✅ Data Processing (Daily 18:30)
3. ✅ Technical Indicators (Daily 19:00)
4. ✅ Sentiment Analysis (Daily 20:00)
5. ✅ Model Training (Weekly Sunday 02:00)
6. ✅ Data Backup (Weekly Sunday 03:00)
7. ✅ Cleanup (Weekly Sunday 04:00)

---

## 📊 Database Schema

### 7 Tables Created:

1. **stocks** - Stock information (symbol, name, exchange, sector)
2. **stock_prices** - Historical OHLCV data
3. **technical_indicators** - RSI, MACD, SMA, EMA, Bollinger Bands, etc.
4. **sentiment_analysis** - Daily sentiment scores from news
5. **model_metrics** - Training metrics for all models
6. **predictions** - Future price predictions
7. **news_articles** - Scraped news for sentiment analysis

### Relationships:

```
stocks (1) ─┬─► (N) stock_prices
            ├─► (N) technical_indicators
            ├─► (N) sentiment_analysis
            └─► (N) predictions

model_metrics (1) ─► (N) predictions
```

---

## 🔧 Configuration

### Environment Variables:

```bash
# .env file (local)
DATABASE_URL=postgresql://postgres:password@localhost:5432/kltn_stocks

# Railway (auto-injected)
DATABASE_URL=${{Postgres.DATABASE_URL}}
PORT=8000
ENVIRONMENT=production
```

### Alembic Commands:

```bash
# Create new migration
alembic revision --autogenerate -m "Add new table"

# Apply migrations
alembic upgrade head

# Rollback one version
alembic downgrade -1

# Check current version
alembic current

# View migration history
alembic history
```

---

## 📡 API Endpoints Reference

### Full list (20+ endpoints):

```
Root:
  GET  /                      - API overview
  GET  /api/health            - Health check

Stocks:
  GET  /api/stocks            - List all stocks
  GET  /api/stocks/{symbol}   - Get stock details
  GET  /api/stocks/search?q=  - Search stocks

Prices:
  GET  /api/prices/{symbol}           - Historical prices
  GET  /api/prices/{symbol}/latest    - Latest price
  GET  /api/prices/{symbol}/ohlcv     - OHLCV data for charts

Indicators:
  GET  /api/indicators/{symbol}        - Technical indicators
  GET  /api/indicators/{symbol}/latest - Latest indicators

Predictions:
  POST /api/predictions/predict        - Create prediction
  GET  /api/predictions/{symbol}       - Get predictions
  GET  /api/predictions/{symbol}/latest - Latest prediction

Sentiment:
  GET  /api/sentiment/{symbol}        - Sentiment history
  GET  /api/sentiment/{symbol}/latest - Latest sentiment

Models:
  GET  /api/models                    - List all models
  GET  /api/models/{symbol}           - Models for stock
  GET  /api/models/{symbol}/{name}    - Specific model metrics

Statistics:
  GET  /api/stats/overview            - System overview
  GET  /api/stats/stocks              - Per-stock statistics

Backtest:
  POST /api/backtest                  - Run backtest simulation
```

### Example Usage:

```python
import requests

# Get all stocks
response = requests.get('https://kltn-api.up.railway.app/api/stocks')
stocks = response.json()

# Get VNM prices (last 30 days)
response = requests.get('https://kltn-api.up.railway.app/api/prices/VNM?limit=30')
prices = response.json()

# Get latest indicators for VNM
response = requests.get('https://kltn-api.up.railway.app/api/indicators/VNM/latest')
indicators = response.json()

# System overview
response = requests.get('https://kltn-api.up.railway.app/api/stats/overview')
stats = response.json()
```

---

## 🧪 Testing

### Run all tests:

```bash
python test_railway_setup.py
```

### Expected output:

```
========================================
TEST 1: Environment Variables
========================================
✅ DATABASE_URL: postgresql://postgres:****@localhost:5432/kltn_stocks

========================================
TEST 2: Database Connection
========================================
✅ Connected to PostgreSQL
   Version: PostgreSQL 15.5

========================================
TEST 3: Database Tables
========================================
✅ Table 'stocks' exists
✅ Table 'stock_prices' exists
✅ Table 'technical_indicators' exists
✅ Table 'sentiment_analysis' exists
✅ Table 'model_metrics' exists
✅ Table 'predictions' exists
✅ Table 'news_articles' exists
✅ Table 'alembic_version' exists

... (more tests)

========================================
SUMMARY
========================================
✅ All tests passed! Your Railway setup is ready.
```

---

## 🔄 Migration from CSV to PostgreSQL

### What changed:

| Before (CSV) | After (PostgreSQL) |
|--------------|-------------------|
| `data/raw/*.csv` | `stock_prices` table |
| `data/processed/*.csv` | `technical_indicators` table |
| `data/news/*.csv` | `news_articles` table |
| Python scheduler | n8n workflows |
| File I/O operations | SQL queries |
| No relationships | Foreign keys & indexes |

### Data migration script:

```python
# Migrate existing CSV data to PostgreSQL
from src.database.helpers import save_stock_prices_to_db
import pandas as pd
import glob

# Migrate all CSV files
for csv_file in glob.glob('data/raw/*_raw_*.csv'):
    df = pd.read_csv(csv_file)
    symbol = csv_file.split('/')[-1].split('_')[0]
    
    count = save_stock_prices_to_db(symbol, df, source='migration')
    print(f"✅ Migrated {count} records for {symbol}")
```

---

## 📈 Performance & Optimization

### Database Indexes:

All tables have proper indexes for fast queries:
- `stocks.symbol` (unique)
- `stock_prices.(stock_id, date)` (compound, unique)
- `technical_indicators.(stock_id, date)` (compound, unique)
- `predictions.(stock_id, target_date)` (compound)

### Query Optimization:

```python
# ❌ Bad: N+1 query problem
for symbol in ['VNM', 'VIC', 'HPG']:
    stock = db.query(Stock).filter(Stock.symbol == symbol).first()
    prices = db.query(StockPrice).filter(StockPrice.stock_id == stock.id).all()

# ✅ Good: Use joins
stocks = db.query(Stock).filter(
    Stock.symbol.in_(['VNM', 'VIC', 'HPG'])
).all()

for stock in stocks:
    prices = stock.prices  # Uses relationship, already loaded
```

---

## 🚨 Troubleshooting

### Issue: Database connection failed

```bash
# Check DATABASE_URL
echo $DATABASE_URL

# Test connection
psql $DATABASE_URL

# Verify Railway variable
railway variables --service Postgres
```

### Issue: Alembic migration failed

```bash
# Check current version
alembic current

# Force stamp to head
alembic stamp head

# Retry upgrade
alembic upgrade head
```

### Issue: n8n workflows not triggering

```
1. Check n8n execution log
2. Verify PostgreSQL credential in n8n
3. Test webhook URL
4. Check timezone settings (Asia/Ho_Chi_Minh)
```

---

## 📚 Additional Resources

- **Railway Docs**: https://docs.railway.app
- **n8n Docs**: https://docs.n8n.io
- **SQLAlchemy Docs**: https://docs.sqlalchemy.org
- **Alembic Docs**: https://alembic.sqlalchemy.org
- **FastAPI Docs**: https://fastapi.tiangolo.com

---

## ✅ Checklist

- [x] PostgreSQL database setup
- [x] SQLAlchemy models created (7 tables)
- [x] Alembic migrations configured
- [x] Database helpers implemented
- [x] FastAPI endpoints expanded (20+)
- [x] n8n workflows documented (7 workflows)
- [x] Railway deployment guide
- [x] Test script created
- [x] .env.example updated
- [x] requirements.txt updated

---

## 🎯 Next Steps

1. **Deploy to Railway**: Follow `docs/RAILWAY_DEPLOYMENT.md`
2. **Setup n8n**: Import workflows from `automation/N8N_WORKFLOWS.md`
3. **Test API**: Run `test_railway_setup.py`
4. **Collect data**: Trigger n8n Workflow 1
5. **Monitor**: Check Railway metrics & n8n execution logs

---

**Total implementation**: ✅ Complete (100%)

**Ready for**: Production deployment on Railway + n8n
