
╔════════════════════════════════════════════════════════════╗
║         RAILWAY DEPLOY - CHỈ 3 BƯỚC (5 PHÚT)              ║
╚════════════════════════════════════════════════════════════╝

📍 BƯỚC 1: TẠO TÀI KHOẢN RAILWAY (1 phút)
   ┌────────────────────────────────────────────────────────┐
   │ 1. Mở: https://railway.app                            │
   │ 2. Click "Start a New Project"                        │
   │ 3. Login với GitHub                                   │
   │ 4. Authorize Railway app                              │
   └────────────────────────────────────────────────────────┘

📍 BƯỚC 2: DEPLOY DATABASE (30 giây)
   ┌────────────────────────────────────────────────────────┐
   │ 1. Railway Dashboard → "New Project"                  │
   │ 2. Chọn "Deploy PostgreSQL"                           │
   │ 3. Đợi 30 giây → Database ready ✅                    │
   │ 4. Click vào PostgreSQL → "Connect"                   │
   │ 5. Copy DATABASE_URL (để dùng sau)                    │
   └────────────────────────────────────────────────────────┘
   
   💡 TIP: DATABASE_URL sẽ có dạng:
   postgresql://postgres:XXX@containers-us-west-XXX.railway.app:5432/railway

📍 BƯỚC 3: DEPLOY API (3 phút)
   
   🅰️ OPTION A: Deploy từ GitHub (Dễ nhất)
   ┌────────────────────────────────────────────────────────┐
   │ 1. Push code lên GitHub:                              │
   │    git add .                                           │
   │    git commit -m "Deploy to Railway"                  │
   │    git push origin main                               │
   │                                                        │
   │ 2. Railway → "New" → "GitHub Repo"                    │
   │ 3. Chọn repo KLTN của bạn                             │
   │ 4. Railway tự động detect Procfile → Deploy           │
   │                                                        │
   │ 5. Thêm biến môi trường:                              │
   │    Settings → Variables → Add Reference               │
   │    DATABASE_URL = ${{Postgres.DATABASE_URL}}          │
   │                                                        │
   │ 6. Generate domain:                                   │
   │    Settings → Networking → Generate Domain            │
   │    → Bạn sẽ có: https://kltn-api.up.railway.app      │
   └────────────────────────────────────────────────────────┘

   🅱️ OPTION B: Deploy từ CLI (Nếu có Railway CLI)
   ┌────────────────────────────────────────────────────────┐
   │ 1. Cài Railway CLI:                                   │
   │    npm install -g @railway/cli                        │
   │                                                        │
   │ 2. Login:                                             │
   │    railway login                                      │
   │                                                        │
   │ 3. Link project:                                      │
   │    railway link                                       │
   │                                                        │
   │ 4. Deploy:                                            │
   │    railway up                                         │
   └────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════

🎉 SAU KHI DEPLOY XONG:

1️⃣ Test API:
   curl https://your-app.railway.app/api/health
   
2️⃣ Xem docs:
   https://your-app.railway.app/docs

3️⃣ Chạy migrations (lần đầu):
   # Option 1: Từ local
   DATABASE_URL=postgresql://... alembic upgrade head
   
   # Option 2: Từ Railway CLI
   railway run alembic upgrade head

4️⃣ Seed initial data:
   railway run python -c "
   from src.database.connection import SessionLocal
   from src.database.models import Stock
   db = SessionLocal()
   stocks = [
       Stock(symbol='VNM', name='Vinamilk', exchange='HOSE', is_active=True),
       Stock(symbol='VIC', name='Vingroup', exchange='HOSE', is_active=True),
   ]
   db.bulk_save_objects(stocks)
   db.commit()
   print('✅ Seeds created')
   "

═══════════════════════════════════════════════════════════

📊 CHI PHÍ:

   FREE TIER: $5 credit/month (ĐỦ CHO KLTN!)
   ┌────────────────────────────────────┐
   │ PostgreSQL:  ~$0.50/month          │
   │ FastAPI:     ~$2.00/month          │
   │ n8n:         ~$2.00/month          │
   │ ─────────────────────────────────  │
   │ TỔNG:        ~$4.50/month ✅       │
   └────────────────────────────────────┘

═══════════════════════════════════════════════════════════

🆘 TROUBLESHOOTING:

❌ "Build failed" → Check logs: Railway → Deployments → View Logs
❌ "502 Bad Gateway" → Kiểm tra PORT variable và Procfile
❌ "Database connection failed" → Verify DATABASE_URL đúng format
❌ "Module not found" → Thêm vào requirements.txt

═══════════════════════════════════════════════════════════

📚 TÀI LIỆU CHI TIẾT:

- Full guide: docs/RAILWAY_DEPLOYMENT.md
- n8n workflows: automation/N8N_WORKFLOWS.md
- API docs: src/api_v2.py

═══════════════════════════════════════════════════════════
