"""Features module for technical indicators and sentiment analysis"""
